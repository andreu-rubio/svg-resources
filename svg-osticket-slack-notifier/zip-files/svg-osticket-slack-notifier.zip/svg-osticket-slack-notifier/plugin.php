<?php

return array(
    'id'          => 'osticket:discord',
    'version'     => '0.1',
    'name'        => 'Discord notifier',
    'author'      => 'RaithSphere',
    'description' => 'Notify Discord on new ticket.',
    'url'         => 'https://github.com/RaithSphere/osTicket-Discord-plugin',
    'plugin'      => 'discord.php:DiscordPlugin',
);
